function toggleMenu() {
    let menuToggle = document.querySelector(".toggle");
    let menu = document.querySelector(".menu");
    menuToggle.classList.toggle("active")
    menu.classList.toggle("active")
};



let getOverlay = document.querySelector(".overlay");
let closeDescktop = document.querySelector(".closeBtnDesktop");
let closeModile = document.querySelector(".closeBtnMobile");

window.addEventListener("load", function () {
    setTimeout(function () {
        getOverlay.classList.add("show");
    }, 2000)

})
closeDescktop.addEventListener("click", function () {
    getOverlay.classList.remove("show");
});

closeModile.addEventListener("click", function () {
    getOverlay.classList.remove("show");
})